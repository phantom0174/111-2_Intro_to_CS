package A9_111502552;


public class Token {
	private String token, type;
	
	Token(String token, String type) {
		this.token = token;
		this.type = type;
	}
	
	// getter 
	public String getToken() {
		return this.token;
	}
	
	public String getType() {
		return this.type;
	}
	// end getter
	
	public void get_token() {
	}
	
	public void get_token_type() {
	}
}
