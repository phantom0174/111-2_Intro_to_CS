package A13_111502552;

public class Benz extends BaseCar {

	public Benz(String driver, int driver_boost) {
		super(driver, 14, 5, driver_boost);
	}
	
}
