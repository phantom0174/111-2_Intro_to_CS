package A13_111502552;

public class Mazda extends BaseCar {

	public Mazda(String driver, int driver_boost) {
		super(driver, 11, 2, driver_boost);
	}

}
