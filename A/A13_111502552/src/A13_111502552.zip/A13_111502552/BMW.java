package A13_111502552;

public class BMW extends BaseCar {

	public BMW(String driver, int driver_boost) {
		super(driver, 8, 8, driver_boost);
	}
	
}
